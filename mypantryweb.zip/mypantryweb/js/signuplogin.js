$(document).ready(function(){
    $("#signup_btn").click(function(){
        $("#main").animate({left:"22.5%"},400);
        $("#main").animate({left:"30%"},500);
        $("#loginform").css("visibility","hidden");
        $("#loginform").animate({left:"25%"},400);
        $("#signupform").animate({left:"17%"},400);
        $("#signupform").animate({left:"30%"},500);
        $("#signupform").css("visibility","visible");
    });
    $("#login_btn").click(function(){
        $("#main").animate({left:"77.5%"},400);
        $("#main").animate({left:"70%"},500);
        $("#signupform").css("visibility","hidden");
        $("#signupform").animate({left:"75%"},400);
        $("#loginform").animate({left:"83.5%"},400);
        $("#loginform").animate({left:"70%"},500);
        $("#loginform").css("visibility","visible");
    });

    $('#signup, #login, #put, #delete, #get').on("click", function() {
        if (this.id == 'get'){
            ajaxGet();
        }
        else if (this.id == 'signup') {
            ajaxPost();
        }
//        else if (this.id == 'login') {
//            ajaxAuthentiacate();
//        }
        else if (this.id == 'put') {
            ajaxPut();
        }

        else if (this.id == 'delete') {
            ajaxDelete();
        }
    });

    function ajaxGet(){
        $.ajax({
                url: "http://localhost:8080/user",
                type : "GET",
                crossDomain:true,
                crossOrigin:true,

                error: function(xhr, status, errorThrown) {
                    alert(status, errorThrown);
                    console.log("xhr: " + xhr);
                    console.log("status: " + status);
                    console.log("errorThrown: " + errorThrown);
                }
            })
        .then(function(data, status, xhr) {
            console.log("xhr: " + xhr);
            console.log("status: " + status);
            console.log("data: "+ data);
            var table = '<table><thead><th>Id</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Phone Number</th></thead><tbody>';
                var obj = data;
                $.each(obj, function() {
                    table += '<tr><td>' + this['id'] + '</td><td>' + this['firstName'] + '</td><td>' + this['lastName'] + '</td><td>' + this['email'] + '</td><td>' + this['phoneNumber'] + '</td></tr>';
                });
                table += '</tbody></table>';
                document.getElementById("datalist").innerHTML = table;
                $('.message').append(data);
        });
    }

    function ajaxPost(){
        var formData = {
            firstName : $("#firstname").val(),
            lastName : $("#lastname").val(),
            email : $("#email").val(),
            phoneNumber : $("#phonenumber").val()
        }

        $.ajax({
            type : "POST",
            crossDomain:true,
            crossOrigin:true,
            contentType : "application/json",
            url : "http://localhost:8080/user",
            data : JSON.stringify(formData),
            dataType : 'json',
            success : function(){
                alert("Success");
            },
            error : function() {
                alert("Error!");
            }
        });

        resetData();
    }

    function ajaxPut(){
        var id = $("#testid").val();

        var formData = {
            address1 : $("#testfirstname").val(),
            address2 : $("#testlastname").val(),
            city : $("#testemail").val(),
            state : $("#testphonenumber").val()
        }
        $.ajax({
            type : "PUT",
            crossDomain:true,
            crossOrigin:true,
            contentType : "application/json",
            url : "http://localhost:8080/user/" + id,
            data : JSON.stringify(formData),
            dataType : 'json',
            success : function(){
                alert("Success");
            },
            error : function() {
                alert("Error!");
            }
        });
    }

    function ajaxDelete(){
        var id = $("#testid").val();

        $.ajax({
            type : "DELETE",
            crossDomain: true,
            crossOrigin: true,
            contentType : "application/json",
            url : "http://localhost:8080/user/" + id,
            success : function(){
                alert("Success");
            },
            error : function() {
                alert("Error!");
            }
        });
    }

    function resetData(){
        $("#firstname").val("");
        $("#lastname").val("");
        $("#email").val("");
        $("#phonenumber").val("");
    }
});